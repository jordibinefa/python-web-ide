# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk

f = tk.Tk()
f.title("Test Checkbutton")

acceptar = tk.IntVar(f, value=0)

def comprovar():
    if acceptar.get():
        etiqueta.config(text="Marcat!")
    else:
        etiqueta.config(text="Sense marcar")

tk.Checkbutton(f, text="Accepto les condicions", variable=acceptar, command=comprovar).pack()
etiqueta = tk.Label(f, text="Sense marcar")
etiqueta.pack()
tk.Button(f, text="Sortir", command=f.destroy).pack()

f.mainloop()
print("acceptar final:", acceptar.get())
