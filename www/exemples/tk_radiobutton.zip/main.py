# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk

f = tk.Tk()
f.title("Test Radiobutton")

operador = tk.StringVar(f, value="+")

def calcular():
    print("Operador seleccionat:", operador.get())

tk.Label(f, text="Tria operació:").pack()
tk.Radiobutton(f, text="+", variable=operador, value="+").pack()
tk.Radiobutton(f, text="*", variable=operador, value="*").pack()
tk.Radiobutton(f, text="/", variable=operador, value="/").pack()
tk.Radiobutton(f, text="-", variable=operador, value="-").pack()
tk.Button(f, text="Calcular", command=calcular).pack()
tk.Button(f, text="Sortir", command=f.destroy).pack()

f.mainloop()
print("mainloop() acabat.")
