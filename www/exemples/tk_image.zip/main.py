# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk

f = tk.Tk()
f.title("Test PhotoImage")
foto = tk.PhotoImage(file="logoEcat.png")  # el que has importat

visible = True  # estat actual: la imatge es veu o no

def commutar():
    global visible
    if visible:
        etiqueta_img.config(image="")
        boto_commutar.config(text="Ensenya")
    else:
        etiqueta_img.config(image=foto)
        boto_commutar.config(text="Amaga")
    visible = not visible

tk.Label(f, text="La meva imatge:").pack()
etiqueta_img = tk.Label(f, image=foto)
etiqueta_img.pack()
boto_commutar = tk.Button(f, text="Amaga", command=commutar)
boto_commutar.pack()
tk.Button(f, text="Surt", command=f.destroy).pack()

f.mainloop()
