# Bucle while
nAny = 2017
while nAny <= 2020:
    print("A l'any %d" % nAny)
    nAny += 1
else:
    print("No n'hi ha més")

print()

# Bucle for (fa el mateix recorregut amb range())
for nAny in range(2017, 2021):
    print("A l'any %d" % nAny)
else:
    print("No n'hi ha més")
