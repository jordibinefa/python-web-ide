# crida.py

def nLaTevaEdat():
    return int(input("La teva edat: "))

if __name__ == "__main__":
    print("Dius tenir %d anys" % nLaTevaEdat())
