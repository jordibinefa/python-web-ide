# main.py
import crida

nEdat = crida.nLaTevaEdat()
print("Heu dit que teniu %d anys" % nEdat)
