nX = int(input("Si us plau, entreu un número enter: "))
if nX < 0:
    nX = 0
    print('Negatiu canviat a zero')
elif nX == 0:
    print('Zero')
elif nX == 1:
    print('Un')
else:
    print('Més')
print("nX: %d" % nX)
