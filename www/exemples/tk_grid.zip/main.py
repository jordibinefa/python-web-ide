# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk

f = tk.Tk()
f.title("Test grid() amb 2 files")

print("Afegint 4 widgets en una graella de 2x2...")
tk.Label(f, text="Fila 0, Col 0").grid(column=0, row=0)
tk.Label(f, text="Fila 0, Col 1").grid(column=1, row=0)
tk.Label(f, text="Fila 1, Col 0").grid(column=0, row=1)
tk.Label(f, text="Fila 1, Col 1").grid(column=1, row=1)
tk.Button(f, text="Surt", command=f.destroy).grid(column=0, row=2, columnspan=2)

print("Comprova visualment: els 4 Label han de quedar en una graella 2x2 real")
print("(fila/columna), no tots en una sola línia.")
f.mainloop()
print("mainloop() acabat.")
