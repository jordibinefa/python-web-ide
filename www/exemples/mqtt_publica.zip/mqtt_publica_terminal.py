# Exemple MQTT — PUBLICADOR (versió per a TERMINAL, tkinter/paho-mqtt reals)
# ---------------------------------------------------------------------------
# Equivalent, per executar amb "python3 mqtt_publica_terminal.py", de
# main.py (pensat per a py.binefa.cat). Publica l'hora cada 5 segons al
# topic "arrel/hora".
#
# Aquest fitxer NOMÉS es fa servir des d'un terminal — no el pugis a
# py.binefa.cat (allà fes servir main.py, que té l'"await" solt que
# necessita l'IDE perquè el botó "Interromp" funcioni bé). Com que aquí
# només cal donar suport a UN entorn, no fa falta cap detecció ni
# bifurcació: sempre "async def" + "asyncio.run()".
#
# El broker.emqx.io al port 8084 és WebSocket segur (wss); amb paho-mqtt
# real i el transport TCP per defecte, connecta millor pel port 1883
# (MQTT normal, sense wss) — per això el codi de sota ja fa servir 1883.
#
# Atura amb Ctrl+C.
# ---------------------------------------------------------------------------

import asyncio
import time
import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connectat al broker")
    else:
        print("Error de connexio, codi:", rc)


client = mqtt.Client()
client.on_connect = on_connect

# --- Broker amb usuari i contrasenya -------------------------------------
# client.username_pw_set("usuari", "contrasenya")
# -------------------------------------------------------------------------

client.connect("broker.emqx.io", 1883, 60)
client.loop_start()


async def bucle_principal():
    while True:
        ara = time.strftime("%H:%M:%S")
        client.publish("arrel/hora", ara)
        print("Publicat:", ara, "-> arrel/hora")
        await asyncio.sleep(5)


asyncio.run(bucle_principal())
