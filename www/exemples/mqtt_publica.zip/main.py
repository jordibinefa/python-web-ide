# Exemple MQTT — PUBLICADOR (model asincron del navegador)
# ---------------------------------------------------------------------------
# Publica l'hora cada 5 segons al topic "arrel/hora".
#
# Al navegador, MQTT nomes funciona sobre WebSocket segur (wss). En aquest
# entorn el port ja determina el protocol automaticament:
#       broker.emqx.io  port 8084  ->  wss://broker.emqx.io:8084/mqtt
#
# REGLA D'OR (navegador): fes servir SEMPRE "await asyncio.sleep(...)",
# mai "time.sleep(...)". time.sleep bloqueja el bucle d'esdeveniments i la
# connexio MQTT deixa de respondre (no es publica ni es rep res).
#
# Atura el programa amb el boto "Interromp".
#
# Vols provar aquest mateix codi des d'un terminal (tkinter/paho-mqtt
# reals)? Fes servir mqtt_publica_terminal.py en lloc d'aquest fitxer.
# Aquest main.py es queda deliberadament amb l'"await" solt de nivell
# superior perque el boto "Interromp" de l'IDE funcioni correctament — un
# "async def"+"asyncio.ensure_future()" (necessari per a fer-lo portable)
# fa que el codi de nivell superior acabi de seguida i "Interromp" deixi
# de poder aturar la tasca de fons (provat i descartat expressament).
# ---------------------------------------------------------------------------

import asyncio
import time
import paho.mqtt.client as mqtt


# Callback que salta quan la connexio amb el broker s'ha completat.
# Signatura Paho: on_connect(client, userdata, flags, rc)
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connectat al broker")
    else:
        print("Error de connexio, codi:", rc)


client = mqtt.Client()
client.on_connect = on_connect

# --- Broker amb usuari i contrasenya -------------------------------------
# Per a un broker privat, descomenta la linia seguent i posa-hi les teves
# credencials ABANS de connect():
# client.username_pw_set("usuari", "contrasenya")
# -------------------------------------------------------------------------

client.connect("broker.emqx.io", 8084, 60)
client.loop_start()   # al navegador es automatic (no bloqueja)

# NOTA: "arrel" es un topic generic en un broker PUBLIC: qualsevol altre
# pot publicar-hi o llegir-lo. Per a proves a classe, canvia "arrel" per
# alguna cosa unica (p. ex. "pyweb/elteunom").
while True:
    ara = time.strftime("%H:%M:%S")
    client.publish("arrel/hora", ara)
    print("Publicat:", ara, "-> arrel/hora")
    await asyncio.sleep(5)
