# Aquest exemple funciona igual al navegador i des d'un terminal, sense cap
# canvi de codi. Única diferència de comportament (no cal fer-hi res):
#   - Al navegador (py.binefa.cat), plt.show() envia la imatge com a PNG a
#     la consola de l'IDE (el worker el pateja internament).
#   - Al terminal, plt.show() obre una finestra real amb el backend gràfic
#     que tinguis instal·lat (p. ex. TkAgg); si no en tens cap de disponible
#     (servidor sense pantalla), pots desar la figura amb
#     fig.savefig("sortida.png") en lloc de mostrar-la.
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 2 * np.pi, 300)

fig, axes = plt.subplots(1, 2, figsize=(10, 4))

axes[0].plot(x, np.sin(x), color='steelblue', linewidth=2)
axes[0].set_title('Sinus')
axes[0].set_xlabel('x')
axes[0].grid(True, alpha=0.3)

axes[1].plot(x, np.cos(x), color='tomato', linewidth=2)
axes[1].set_title('Cosinus')
axes[1].set_xlabel('x')
axes[1].grid(True, alpha=0.3)

fig.suptitle('Funcions trigonomètriques', fontsize=13)
plt.tight_layout()
plt.show()
