# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk

f = tk.Tk()
f.title("Test Listbox")

def veure_seleccio():
    idx = lista.curselection()
    if idx:
        etiqueta.config(text="Has triat: " + lista.get(idx[0]))
    else:
        etiqueta.config(text="Cap selecció")

tk.Label(f, text="Tria una fruita:").pack()
lista = tk.Listbox(f)
lista.insert(tk.END, "Pomes")
lista.insert(tk.END, "Peres")
lista.insert(tk.END, "Plàtans")
lista.insert(tk.END, "Cireres")
lista.insert(tk.END, "Alvocats")
lista.pack()

etiqueta = tk.Label(f, text="")
etiqueta.pack()
tk.Button(f, text="Veure selecció", command=veure_seleccio).pack()
tk.Button(f, text="Sortir", command=f.destroy).pack()

f.mainloop()
print("mainloop() acabat.")
