# Exemple MQTT — SUBSCRIPTOR (versió per a TERMINAL, tkinter/paho-mqtt reals)
# ---------------------------------------------------------------------------
# Equivalent, per executar amb "python3 mqtt_subscriu_terminal.py", de
# main.py (pensat per a py.binefa.cat). Es subscriu a "arrel/#" i imprimeix
# tot el que hi arriba.
#
# Aquest fitxer NOMÉS es fa servir des d'un terminal — no el pugis a
# py.binefa.cat (allà fes servir main.py). Com que aquí només cal donar
# suport a UN entorn, no fa falta cap detecció ni bifurcació: sempre
# "async def" + "asyncio.run()".
#
# El broker.emqx.io al port 8084 és WebSocket segur (wss); amb paho-mqtt
# real i el transport TCP per defecte, connecta millor pel port 1883
# (MQTT normal, sense wss) — per això el codi de sota ja fa servir 1883.
#
# Atura amb Ctrl+C.
# ---------------------------------------------------------------------------

import asyncio
import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connectat al broker")
        client.subscribe("arrel/#")
        print("Subscrit a arrel/#")
    else:
        print("Error de connexio, codi:", rc)


def on_message(client, userdata, msg):
    text = msg.payload.decode("utf-8")
    print("Tema:", msg.topic, "-> Missatge:", text)


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# --- Broker amb usuari i contrasenya -------------------------------------
# client.username_pw_set("usuari", "contrasenya")
# -------------------------------------------------------------------------

client.connect("broker.emqx.io", 1883, 60)
client.loop_start()


async def bucle_principal():
    print("Esperant missatges a arrel/# ...")
    while True:
        await asyncio.sleep(1)


asyncio.run(bucle_principal())
