# Exemple MQTT — SUBSCRIPTOR (model asincron del navegador)
# ---------------------------------------------------------------------------
# Es subscriu a "arrel/#" i imprimeix tot el que hi arriba.
#
# El bucle final "while True: await asyncio.sleep(1)" nomes mante el
# programa viu: NO fa res actiu. Els missatges entrants salten sols a
# on_message mentre el programa "dorm" a l'await.
#
# REGLA D'OR (navegador): SEMPRE "await asyncio.sleep(...)", mai
# "time.sleep(...)" (bloquejaria la recepcio).
#
# Per provar-ho: obre aquest subscriptor i, en una altra pestanya/finestra,
# executa l'exemple PUBLICADOR. Atura amb el boto "Interromp".
#
# Vols provar aquest mateix codi des d'un terminal (tkinter/paho-mqtt
# reals)? Fes servir mqtt_subscriu_terminal.py en lloc d'aquest fitxer.
# Aquest main.py es queda deliberadament amb l'"await" solt de nivell
# superior perque el boto "Interromp" de l'IDE funcioni correctament — un
# "async def"+"asyncio.ensure_future()" (necessari per a fer-lo portable)
# fa que el codi de nivell superior acabi de seguida i "Interromp" deixi
# de poder aturar la tasca de fons (provat i descartat expressament).
# ---------------------------------------------------------------------------

import asyncio
import paho.mqtt.client as mqtt


# Signatura Paho: on_connect(client, userdata, flags, rc)
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connectat al broker")
        client.subscribe("arrel/#")    # "#" = tots els subtopics d'"arrel"
        print("Subscrit a arrel/#")
    else:
        print("Error de connexio, codi:", rc)


# Signatura Paho: on_message(client, userdata, msg)
#   msg.topic   -> str amb el topic
#   msg.payload -> bytes (per aixo cal .decode("utf-8"))
def on_message(client, userdata, msg):
    text = msg.payload.decode("utf-8")
    print("Tema:", msg.topic, "-> Missatge:", text)


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# --- Broker amb usuari i contrasenya -------------------------------------
# client.username_pw_set("usuari", "contrasenya")
# -------------------------------------------------------------------------

client.connect("broker.emqx.io", 8084, 60)
client.loop_start()

print("Esperant missatges a arrel/# ...")
while True:
    await asyncio.sleep(1)
