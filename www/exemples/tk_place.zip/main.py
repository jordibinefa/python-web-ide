# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk

f = tk.Tk()
f.title("Test place()")
f.geometry("300x200")

etiqueta = tk.Label(f, text="Nom: ")
etiqueta.place(x=60, y=20, width=120)

entrada = tk.Entry(f)
entrada.place(x=110, y=20, width=100)

tk.Button(f, text="Surt", command=f.destroy).place(x=110, y=60, width=100)

print("Comprova visualment: etiqueta i entry han de quedar a la mateixa")
print("alçada (y=20), un al costat de l'altre, NO un sota l'altre.")
f.mainloop()
print("mainloop() acabat.")
