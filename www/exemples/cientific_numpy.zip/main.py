import numpy as np

a = np.array([1, 2, 3, 4, 5])
print("Array:", a)
print("Suma:", a.sum())
print("Mitjana:", a.mean())
print("Quadrats:", a ** 2)

b = np.linspace(0, 10, 5)
print("Linspace (5 valors entre 0 i 10):", b)

matriu = np.array([[1, 2], [3, 4]])
print("Matriu:")
print(matriu)
print("Transposada:")
print(matriu.T)
