# Exemple MQTT — PUBLICADOR + SUBSCRIPTOR (versió per a TERMINAL, reals)
# ---------------------------------------------------------------------------
# Equivalent, per executar amb "python3 mqtt_pub_sub_terminal.py", de
# main.py (pensat per a py.binefa.cat).
#
# Aquest fitxer NOMÉS es fa servir des d'un terminal — no el pugis a
# py.binefa.cat (allà fes servir main.py). Com que aquí només cal donar
# suport a UN entorn, no fa falta cap detecció ni bifurcació: sempre
# "async def" + "asyncio.run()".
#
# El broker.emqx.io al port 8084 és WebSocket segur (wss); amb paho-mqtt
# real i el transport TCP per defecte, connecta millor pel port 1883
# (MQTT normal, sense wss) — per això el codi de sota ja fa servir 1883.
#
# Atura amb Ctrl+C.
# ---------------------------------------------------------------------------

import asyncio
import time
import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connectat al broker")
        client.subscribe("arrel/#")
        print("Subscrit a arrel/#")
    else:
        print("Error de connexio, codi:", rc)


def on_message(client, userdata, msg):
    print("[REBUT]   ", msg.topic, "->", msg.payload.decode("utf-8"))


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# --- Broker amb usuari i contrasenya -------------------------------------
# client.username_pw_set("usuari", "contrasenya")
# -------------------------------------------------------------------------

client.connect("broker.emqx.io", 1883, 60)
client.loop_start()


async def bucle_principal():
    while True:
        ara = time.strftime("%H:%M:%S")
        client.publish("arrel/hora", ara)
        print("[PUBLICAT]", ara, "-> arrel/hora")
        await asyncio.sleep(5)


asyncio.run(bucle_principal())
