# Exemple MQTT — PUBLICADOR + SUBSCRIPTOR ALHORA (model asincron)
# ---------------------------------------------------------------------------
# El cas clau del navegador: publicar a intervals I rebre al mateix temps,
# en un sol fil, gracies a asyncio.
#
#   - on_message salta sol quan arriba qualsevol cosa a "arrel/#"
#   - el bucle de baix publica l'hora cada 5 s SENSE bloquejar la recepcio
#
# Com que el programa esta subscrit a "arrel/#" i publica a "arrel/hora",
# rebra els SEUS PROPIS missatges: veuras un [PUBLICAT] i, tot seguit, el
# [REBUT] corresponent. Aixo demostra que pub i sub conviuen en el mateix
# fil sense bloquejar-se.
#
# REGLA D'OR (navegador): SEMPRE "await asyncio.sleep(...)", mai
# "time.sleep(...)". Amb time.sleep, durant l'espera no es rebria res.
#
# Atura amb el boto "Interromp".
#
# Vols provar aquest mateix codi des d'un terminal (tkinter/paho-mqtt
# reals)? Fes servir mqtt_pub_sub_terminal.py en lloc d'aquest fitxer.
# Aquest main.py es queda deliberadament amb l'"await" solt de nivell
# superior perque el boto "Interromp" de l'IDE funcioni correctament — un
# "async def"+"asyncio.ensure_future()" (necessari per a fer-lo portable)
# fa que el codi de nivell superior acabi de seguida i "Interromp" deixi
# de poder aturar la tasca de fons (provat i descartat expressament).
# ---------------------------------------------------------------------------

import asyncio
import time
import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connectat al broker")
        client.subscribe("arrel/#")
        print("Subscrit a arrel/#")
    else:
        print("Error de connexio, codi:", rc)


def on_message(client, userdata, msg):
    print("[REBUT]   ", msg.topic, "->", msg.payload.decode("utf-8"))


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# --- Broker amb usuari i contrasenya -------------------------------------
# client.username_pw_set("usuari", "contrasenya")
# -------------------------------------------------------------------------

client.connect("broker.emqx.io", 8084, 60)
client.loop_start()

while True:
    ara = time.strftime("%H:%M:%S")
    client.publish("arrel/hora", ara)
    print("[PUBLICAT]", ara, "-> arrel/hora")
    await asyncio.sleep(5)
