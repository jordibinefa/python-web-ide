# Aquest exemple funciona igual al navegador i des d'un terminal, sense
# cap canvi de codi: com que no combina tkinter amb MQTT/async, f.mainloop()
# és la tria correcta (i l'única necessària) als dos llocs.
import tkinter as tk
from tkinter import messagebox

f = tk.Tk()
f.title("Entry, Button i messagebox")

def saludar():
    nom = entrada.get()
    etiqueta_resultat.config(text="Hola " + nom + "!")

def avisar():
    messagebox.showinfo("Info", "Aquest és un avís de prova")

def sortir():
    if messagebox.askokcancel("Sortir", "Segur que vols sortir?"):
        f.destroy()

tk.Label(f, text="Nom:").pack()
entrada = tk.Entry(f)
entrada.pack()
tk.Button(f, text="Saluda", command=saludar).pack()
tk.Button(f, text="Avisa", command=avisar).pack()
etiqueta_resultat = tk.Label(f, text="")
etiqueta_resultat.pack()
tk.Button(f, text="Surt", command=sortir).pack()

f.mainloop()
print("Sortida neta confirmada.")
