try:
    # Intent d'execució d'operacions crítiques
    # La funció input() retorna una cadena que ha de ser convertida a enter
    numero = int(input("Introdueix un número: "))

    # Operació susceptible de generar un ZeroDivisionError
    resultat = 10 / numero
    print(f"El resultat és {resultat}")

except ZeroDivisionError:
    # Gestió específica per a la indeterminació matemàtica de la divisió per zero
    print("Error: No es pot dividir per zero!")

except ValueError:
    # Gestió de l'error produït quan el contingut de l'entrada no és numèric
    print("Error: Has d'introduir un número enter vàlid.")

except Exception as e:
    # Captura generalista d'errors imprevistos per evitar la propagació de l'excepció
    print(f"Ha passat un error imprevist: {e}")

finally:
    # Bloc de tancament per assegurar la integritat del final de la subrutina
    print("Final de la gestió d'errors.")
